#include <iostream>

using namespace std;
int main() {
  int isplayerinRange = 0;
  int isplayerAttacking = 0;
  int isplayerDefending = 0;
  int playerHealth = 0;

  cout<<"______GAME PLAY______"<<endl;
  if(isplayerinRange == 0 && isplayerAttacking == 0)
  {
    cout<<" the enemy should attack"<<endl;
  }
  else if(isplayerDefending == 0)
  {
    cout<<"Enemy should hold"<<endl;
  }
  else if(playerHealth < 20 && isplayerAttacking == 0)
  {
    cout<<"player should deliver a rage attack."<<endl;
  }
  else if(playerHealth == 100 && playerHealth <= 10)
  {
    cout<<"enemy should do a special ability attack"<<endl;
  }
  else{    cout<<"Something went wrong!"<<endl;
  }
}