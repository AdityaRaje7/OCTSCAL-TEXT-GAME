#include <iostream>

using namespace std;

int main() {
  int playerHealth = 100;
  int enemyHealth  = 0;

  cout<<"_______GAME STATUS_______"<<endl;
  if(playerHealth <= 100 && playerHealth >=50)
    cout<<"player health is full.....!"<< endl;
  {
    if(playerHealth <= 50 &&  playerHealth >=1)
      cout<<"player health is half.....!"<< endl;
    {
      if(playerHealth == 0)   
      {
        cout<<":::player is dead:::"<<endl;
      }
    } 
  }

  if(playerHealth != 0 && enemyHealth <= 100 && enemyHealth >=50)
  cout<<"Enemy health is full.....!"<<endl;
  {
    if(enemyHealth <=50 && enemyHealth >=1)
      cout<<"Enemy Health is Half.....!"<<endl;
    {
      if(enemyHealth == 0){
        cout<<":::Enemy is dead:::"<<endl;
      }
    }
    
  }
  if(playerHealth == enemyHealth || playerHealth > enemyHealth || playerHealth < enemyHealth)
    cout<<"GAME OVER"<<endl;
  {
    if(playerHealth > enemyHealth)
      cout<<"Player won!!!!!"<<endl;
   
    {
      if(enemyHealth > playerHealth)
      cout<<"Enemy won!!!!!"<<endl;
      {
        if(playerHealth == enemyHealth)
        {
        cout<<"Match Draw no body wons!!!!!"<<endl;
      }
      }
      
    }
  }

}
